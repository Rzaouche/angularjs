import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
 productList = [
   {name: 'Sabre laser', price: 250},
   {name: 'baton simple', price: 12},
   {name: 'la carrière de gourcuff', price: 0.01},
   {name: 'kirby', price: 56},
   {name: 'piscine gonflable', price: 125000}
  ];
 cartProductList = [];

 addProductToCart(product) {
   const productExistInCart = this.cartProductList.find(({name}) => name === product.name); 
   if (!productExistInCart) {
     this.cartProductList.push({...product, num:1}); 
     return;
   }
   productExistInCart.num += 1;
 }
  removeProduct(product) {
   this.cartProductList = this.cartProductList.filter(({name}) => name !== product.name)
  }
}
